#include "StoryTeller.h"

void StoryTeller::StartWave() {
	// TODO - implement StoryTeller::StartWave
	throw "Not yet implemented";
}

void StoryTeller::startEngine() {
	// TODO - implement StoryTeller::startEngine
	throw "Not yet implemented";
}
