#ifndef STORYTELLER_H
#define STORYTELLER_H

class StoryTeller {


public:
	void StartWave();

	void startEngine();
};

#endif
