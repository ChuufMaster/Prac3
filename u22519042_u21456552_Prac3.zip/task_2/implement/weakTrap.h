#ifndef WEAKTRAP_H
#define WEAKTRAP_H
#include "Trap.h"
#include <string>
using namespace std;
class weakTrap : public Trap {


public:

	weakTrap(Engine* core);
};

#endif
