#ifndef BFS_H
#define BFS_H

#include "Iterator.h"

class BFS : public Iterator {


public:
	Tile* next();
};

#endif
