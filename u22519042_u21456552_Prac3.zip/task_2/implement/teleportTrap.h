#ifndef TELEPORTTRAP_H
#define TELEPORTTRAP_H
#include "Trap.h"
#include <string>
using namespace std;
class teleportTrap : public Trap {


public:

	teleportTrap(Engine* core);
};

#endif
