#ifndef DFS_H
#define DFS_H

#include "Iterator.h"
class DFS :public  Iterator {


public:
	Tile* next();
};

#endif
