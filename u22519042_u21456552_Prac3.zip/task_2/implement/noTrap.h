#ifndef NOTRAP_H
#define NOTRAP_H
#include "Trap.h"
#include <string>
using namespace std;
class noTrap : public Trap {


public:

	noTrap(Engine* core);
};

#endif
