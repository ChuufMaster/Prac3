#ifndef TREASUREHOARD_H
#define TREASUREHOARD_H
#include "Trap.h"
#include <string>
using namespace std;
class treasureHoard : public Trap {


public:

	treasureHoard(Engine* core);

};

#endif
